/**
*@author: Laura Tamath
*@author: Walter Saldana
*@since 24/02/2020
*@version 25/02/2020
Referencia tomada del código de Douglas
**/
public class DoubleList<E>  extends AbstractList<E>{
    public DoubleList(){
        
    }
}